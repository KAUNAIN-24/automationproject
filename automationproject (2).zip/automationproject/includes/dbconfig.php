<?php
// Database connection
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'certificate';
$conn = new mysqli($servername, $username, $password, $dbname);
?>